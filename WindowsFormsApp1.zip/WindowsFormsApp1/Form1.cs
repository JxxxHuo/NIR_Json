﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OxyPlot;
using OxyPlot.Series;
using System.IO;
using Newtonsoft.Json;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var myModel = new PlotModel { Title = "test1" };
            myModel.Series.Add(new FunctionSeries(Math.Cos,0,10,0.1,"cos(x)"));
            this.plotView1.Model = myModel;
        }

		private String filename;
        private List<double> x = new List<double>();
        private List<double> y = new List<double>();


        private void open_Click(object sender, EventArgs e)
        {

         




        }

        private void button1_Click(object sender, EventArgs e)
        {

			openFileDialog1.Filter = "txt file|*.txt";//设置打开文件筛选器
			openFileDialog1.Title = "choose txt file";//设置打开对话框标题
			openFileDialog1.Multiselect = false;//设置打开对话框中只能单选
			if (openFileDialog1.ShowDialog() == DialogResult.OK)//判断是否选择了文件
			{
				filename = openFileDialog1.FileName;//在文本框中显示Excel文件名
                this.textBox1.Text = filename;
				StreamReader SReader = new StreamReader(filename, Encoding.Default);
				string strLine = string.Empty;

				char tab = ',';
                if (filename.Contains("dpt"))
                    tab = ' ';
                List<double> x = new List<double>();
                List<double> y = new List<double>();

                var model = new PlotModel { Title = "LineSeries", Subtitle = "MarkerType = Circle" };
                var lineSeries = new LineSeries { MarkerType = MarkerType.Circle };

                while ((strLine = SReader.ReadLine()) != null)
                {
                    string[] arr = strLine.Trim().Split(tab);

                    // txtSQLQuery = txtSQLQuery + "insert into leaftest (wavenumber, absorption) values (" + arr[0] + "," + arr[1] + ");";
                    double xx=(Convert.ToDouble(arr[0]));
                    double yy=(Convert.ToDouble(arr[1]));
                    x.Add(xx);
                    y.Add(yy);
                    lineSeries.Points.Add(new DataPoint(xx, yy));
                }

                this.x = x;
                this.y = y;

                model.Series.Add(lineSeries);
                this.plotView1.Model = model;

            }

		}

        private void button2_Click(object sender, EventArgs e)
        {

            String absolutionPath = "Z:\\mysqlite3.db";
            SQLiteConnection cnn = new SQLiteConnection();
            cnn.ConnectionString = string.Format("DataSource={0}", absolutionPath);
            cnn.Open();
            string specname = this.textBox2.Text;
            try { 
            var cm = cnn.CreateCommand();
           
            SQLiteTransaction transaction = cnn.BeginTransaction();
            using (var cmd = cnn.CreateCommand())
            {

                    string jsonx = JsonConvert.SerializeObject(this.x);
                    string jsony = JsonConvert.SerializeObject(this.y);
                   
                    // txtSQLQuery = txtSQLQuery + "insert into leaftest (wavenumber, absorption) values (" + arr[0] + "," + arr[1] + ");";											
                    cmd.CommandText = "insert into specjson values('"+specname+"','"+jsonx+"','"+jsony+"');";
                    //cmd.Parameters.Add("@va1",arr[0]);
                    //cmd.Parameters.Add();
                    cmd.ExecuteNonQuery();
                    
              
            }
            //sql_cmd.CommandText = txtSQLQuery;	
            //sql_cmd.ExecuteNonQuery();

            transaction.Commit();
            cnn.Close();

            this.textBox1.Text = "insert into database success!";
        }

			catch (Exception exp)
			{
				this.textBox1.Text = exp.ToString();
			}

}

        private void button3_Click(object sender, EventArgs e)
        {
            String absolutionPath = "Z:\\mysqlite3.db";
            SQLiteConnection cnn = new SQLiteConnection();
            cnn.ConnectionString = string.Format("DataSource={0}", absolutionPath);
            cnn.Open();

            var cm = cnn.CreateCommand();
            cm.CommandText=("select spec from specjson where specname='s1'");

            SQLiteDataReader reader = cm.ExecuteReader();
            string jsonx = null;
            while (reader.HasRows)
            {
                while (reader.Read())
                {
                    jsonx = reader.GetString(0);
                }
            }

            List<string> pp= JsonConvert.DeserializeObject<List<string>>(jsonx);
            List<double> specl = pp.Select(x=>double.Parse(x)).ToList();

            cm = cnn.CreateCommand();
            cm.CommandText = ("select freq from specjson where specname='s1'");

            reader = cm.ExecuteReader();
            string jsony = null;
            while (reader.HasRows)
            {
                while (reader.Read())
                {
                    jsony = reader.GetString(0);
                }
            }

            List<string> p = JsonConvert.DeserializeObject<List<string>>(jsony);
            List<double> freql = p.Select(x => double.Parse(x)).ToList();

            cnn.Close();
        }
    }
}
